// ==UserScript==
// @name         Toggle YouTube video fullscreen on scroll
// @namespace    http://tampermonkey.net/
// @version      2.0
// @description  Exit fullscreen on scroll down, re-enter on scroll back to top
// @match        https://www.youtube.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const isFullscreen = () =>
        !!(document.fullscreenElement || document.webkitFullscreenElement);

    const onWatchPage = () => location.pathname === '/watch';

    // Scroll down inside fullscreen → exit
    document.addEventListener('wheel', (e) => {
        if (!onWatchPage()) return;
        if (isFullscreen() && e.deltaY > 0) {
            (document.exitFullscreen || document.webkitExitFullscreen)?.call(document);
        }
    }, { passive: true, capture: true });

    // Page scrolled back to top and not fullscreen → re-enter
    window.addEventListener('scroll', () => {
        if (!onWatchPage()) return;
        if (window.scrollY === 0 && !isFullscreen()) {
            document.querySelector('.ytp-fullscreen-button')?.click();
        }
    }, { passive: true });
})();